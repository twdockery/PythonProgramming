from drone import Drone

def main():

    # create Drone object

    # set choice to -1

    while choice != 0:

        # input choice

        # if choice is 1, call accelerate method of drone object

        # if choice is 2, call decelerate method of drone object

        # if choice is 3, call ascend method of drone object

        # if choice is 4, call descend method of drone object

        # display Drone object
        
main()

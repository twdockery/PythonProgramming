from course import Course

def main():

    # input course code and max size

    # create Course object, pass course code and max size as arguments

    # initialize choice to -1

    while choice != 0:

        # input choice

        # if choice is 1, call add_student method of Course object and display enrollment of Course object

        # if choice is 2, call drop_student method of Course object and display enrollment of Course object

        # if choice is 3, display course code, max size and enrollment of Course object


main()
